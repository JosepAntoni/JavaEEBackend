/*
 * Copyright (c) 2004, PostgreSQL Global Development Group
 * See the LICENSE file in the project root for more information.
 */

package org.postgresql.jdbc3;

import org.postgresql.ds.PGConnectionPoolDataSource;

/**
 * @deprecated Please use {@link PGConnectionPoolDataSource}
 */
@Deprecated
public class Jdbc3ConnectionPool extends PGConnectionPoolDataSource {
}
